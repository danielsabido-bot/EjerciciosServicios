﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ejercicio2Threads
{
    internal class Program
    {
        static Random random = new Random();
        static bool running = true;
        static int[] caballos = new int[5];
        public static readonly object l = new object();
        public static void caballoCorre(object caballo)
        {
            int numCaballo = (int)caballo;

            while (running)
            {
                lock (l)
                {
                    if (running)
                    {
                        caballos[numCaballo] += random.Next(1, 5);
                        Console.SetCursorPosition(caballos[numCaballo] + 20, numCaballo);
                        Console.WriteLine("*");
                        if (caballos[numCaballo] >= 60)
                        {
                            running = false;
                        }
                    }
                }
                Thread.Sleep(random.Next(0, 250));
            }
        }

        static void Main(string[] args)
        {
            int respuesta = 0;
            int apuesta = 0;
            bool error = false;
            bool repetir = false;
            do
            {
                repetir = false;
                do
                {
                    error = false;
                    Console.WriteLine("Apuesta por un caballo: \n[1]\n[2]\n[3]\n[4]\n[5]");
                    if (!int.TryParse(Console.ReadLine(), out apuesta))
                    {
                        error = true;
                    }
                } while (error || apuesta > 5 || apuesta <= 0);
                Console.Clear();
                for (int i = 0; i < caballos.Length; i++)
                {
                    Console.SetCursorPosition(0, i);
                    Console.WriteLine("Caballo nº" + (i + 1) + ": ");
                }
                Thread[] threads = new Thread[5];
                for (int i = 0; i < caballos.Length; i++)
                {
                    caballos[i] = 0;
                }
                for (int i = 0; i < threads.Length; i++)
                {
                    threads[i] = new Thread(caballoCorre);
                    threads[i].Start(i);
                }
                foreach (Thread thread in threads)
                {
                    thread.Join();
                }
                Console.Clear();
                for (int i = 0; i < caballos.Length; i++)
                {
                    if (caballos[i] >= 60)
                    {
                        Console.WriteLine("Ha ganado el caballo nº" + (i + 1));
                        if ((i + 1) == apuesta)
                        {
                            Console.WriteLine("Ganaste la apuesta!");
                        }
                    }
                }
                do
                {
                    error = false;
                    Console.WriteLine("Volver a jugar?\n [1] Si\n [2] No");
                    if (!int.TryParse(Console.ReadLine(), out respuesta) || respuesta > 2 || respuesta < 1)
                    {
                        error = true;
                        Console.WriteLine("Escribe una respuesta válida.");
                    }
                } while (error);
                if (respuesta == 1)
                {
                    repetir = true;
                    running = true; 
                    for (int i = 0; i < caballos.Length; i++)
                    {
                        caballos[i] = 0;
                    }
                }
            } while (repetir);
        }
    }
}
