﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3Threads
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private async Task<string> DownloadFileAsync(string fileName, int delayMs)
        {
            await Task.Delay(delayMs);
            return $"File {fileName} downloaded in {delayMs} ms.";
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            string resultado = await DownloadFileAsync(txtFileName.Text, r.Next(1, 10));
            textBox1.Text = resultado;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
